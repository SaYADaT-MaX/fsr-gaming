const menuToggle=document.getElementById('menuToggle');
const nav=document.getElementById('nav');
if(menuToggle&&nav){menuToggle.addEventListener('click',()=>nav.classList.toggle('open'));nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));}
document.querySelectorAll('.year').forEach(el=>el.textContent=new Date().getFullYear());
const form=document.getElementById('registrationForm');
if(form){form.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(form);const msg=['FSR GAMING registration draft',`Team: ${d.get('team')}`,`Captain: ${d.get('captain')}`,`UID: ${d.get('uid')}`,`Contact: ${d.get('contact')}`,`Tournament: ${d.get('tournament')}`].join('\\n');document.getElementById('formMessage').textContent='তথ্য প্রস্তুত হয়েছে, কিন্তু এটি কোনো সার্ভারে জমা হয়নি।\\n\\n'+msg;if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(msg).catch(()=>{});});}
