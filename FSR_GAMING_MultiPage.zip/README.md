# FSR GAMING — Multi-page tournament website

## Files
- 9 HTML pages: Home, Tournaments, Free Tournament, Paid Tournament, Registration, Leaderboard, Results, Rules, Contact
- `style.css`: shared Black + Red design and responsive layout
- `script.js`: shared mobile navigation and demo registration form

## Publish on GitHub Pages
1. Create a Public repository named `fsr-gaming`.
2. Extract this ZIP and upload all files directly into the repository root.
3. Open Settings → Pages.
4. Choose Deploy from a branch, select `main` and `/(root)`, then Save.
5. Wait for GitHub Pages to publish the site.

## Important
The registration form is a front-end demo only. It does not save or transmit submitted details. Connect a trusted form service or secure backend before accepting real registrations. No payment collection is implemented. For paid events, publish verified organizer identity, eligibility, fees, prize terms and refund policy, and have a responsible adult review the arrangements.
